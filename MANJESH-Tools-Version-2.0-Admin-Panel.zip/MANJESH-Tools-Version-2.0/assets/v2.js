(() => {
 const menu=document.querySelector('[data-menu]'); const nav=document.querySelector('[data-nav]');
 if(menu&&nav) menu.addEventListener('click',()=>nav.classList.toggle('open'));
 const input=document.querySelector('#toolSearch'); const cards=[...document.querySelectorAll('[data-tool]')]; const empty=document.querySelector('#emptyState');
 function filter(q=''){q=q.trim().toLocaleLowerCase();let n=0;cards.forEach(c=>{const hit=(c.dataset.search+' '+c.textContent).toLocaleLowerCase().includes(q);c.classList.toggle('hide',!hit);if(hit)n++;});if(empty)empty.style.display=n?'none':'block';}
 if(input) input.addEventListener('input',e=>filter(e.target.value));
 document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>{const c=b.dataset.category;if(input)input.value='';cards.forEach(x=>{const hit=c==='all'||(x.dataset.category||'').split(' ').includes(c);x.classList.toggle('hide',!hit)});if(empty)empty.style.display=cards.some(x=>!x.classList.contains('hide'))?'none':'block';document.querySelector('#tools')?.scrollIntoView({behavior:'smooth'});}));
 const year=document.querySelector('[data-year]');if(year)year.textContent=new Date().getFullYear();
})();
