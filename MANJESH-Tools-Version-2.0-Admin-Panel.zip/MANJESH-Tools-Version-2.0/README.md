# MANJESH Tools – Version 2.0 (Upgrade Build)

This package is based on the supplied `manjeshtools-main.zip` snapshot (archive dated 9 Nov 2026).

## What changed
- Rebuilt the homepage with a responsive modern layout, clearer navigation and live tool search/category filters.
- Added local CSS/JS assets and a lightweight SVG brand mark (the source ZIP referenced a logo file that was not included).
- Listed existing tool pages only; no placeholder tools are represented as live.
- Added a clean `/tools/background-remover.html` URL using the existing background-removal page.
- Legacy nested duplicate URLs now forward to the corresponding canonical tool URLs.
- Updated sitemap and added robots.txt.
- Fixed project-root absolute paths on the pricing page.
- Preserved the complete supplied original project under `/_backup_v1/` before changes.

## Important limits / next work
- Existing tool internals have been retained, not comprehensively browser-tested or rewritten. Each should be functionally tested on Android and desktop before production.
- Firebase login and Razorpay subscription activation still require a correctly configured backend/security verification; frontend-only checkout is not proof of paid membership.
- The canonical URLs currently use the existing GitHub Pages address. Update canonical, sitemap and robots.txt if a custom domain is connected.
- GitHub Pages terms state it is not intended/allowed as free hosting for an online business or SaaS. Keep GitHub as the code repository, but choose suitable business hosting before operating MANJESH Tools as a commercial SaaS.

## Publish safely
1. Keep the original ZIP and this output ZIP as separate backups.
2. Review the diff and test all tool pages locally.
3. Upload the upgraded files to the existing repository only after confirming you can restore from `/_backup_v1/`.
4. Do not expose payment secrets or service-account credentials in frontend files.

## Admin panel preview
- Open `admin.html` after deployment to view the MANJESH Tools admin dashboard UI.
- This is a frontend preview only. It has no administrator authentication, database, live publishing, user management, or analytics connection.
- Do not expose sensitive data or rely on this page for access control. Before production use, connect a secure backend and enforce administrator roles server-side (for example, Firebase Authentication with server-verified admin claims and restrictive database rules).
